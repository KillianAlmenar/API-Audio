Tout fonctionne sauf play/pause/stop/resume + volume SEULEMENT pour le Ogg
Mais on peut lire un ogg