#pragma once

int PlayOgg(const char* _path);
