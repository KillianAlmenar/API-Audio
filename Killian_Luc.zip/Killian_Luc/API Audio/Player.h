#pragma once

int Play(const char* fileName);
int init();
void Pause();
void Resume();
void Stop();
void Cleanup();
void SetVolume(float volume);